import software.amazon.awssdk.services.swf.SwfClient;
import software.amazon.awssdk.services.swf.model.ListDomainsRequest;
import software.amazon.awssdk.services.swf.model.ListDomainsResponse;
import software.amazon.awssdk.regions.Region;
public class AWSconnect {
    public static void main(String[] args) {
        SwfClient swf = SwfClient.builder()
                .region(Region.AP_SOUTH_1)
                .build();
        System.out.println("Connected to AWS SWF!");
        ListDomainsRequest request = ListDomainsRequest.builder()
                .registrationStatus("REGISTERED")
                .build();
        ListDomainsResponse response = swf.listDomains(request);
        System.out.println(response);
    }
}
